# -*- coding: utf-8 -*-
"""
Created on Sun Dec  2 09:37:04 2018

@author: 15101079
"""
import numpy as np # linear algebra
import pandas as pd # data processing, CSV file I/O (e.g. pd.read_csv)

from sklearn.model_selection import train_test_split

data = pd.read_csv("column_3C_weka.csv")
data = pd.read_csv("column_3C_weka.csv")
print(data.head())

Y = data['class'].replace('Normal', 0).replace('Spondylolisthesis', 1).replace('Hernia', 2)
x = data.iloc[:,1:6].values

data.rename(columns={
    'class': 'symptom_class'
}, inplace=True)

hernia = data[data.symptom_class == "Hernia"]
spondilolisthesis = data[data.symptom_class == "Spondylolisthesis"]
normal = data[data.symptom_class == "Normal"]
plt.scatter(hernia.lumbar_lordosis_angle, hernia.degree_spondylolisthesis, color = "red",label = "Hernia")
plt.scatter(spondilolisthesis.lumbar_lordosis_angle, spondilolisthesis.degree_spondylolisthesis, color = "blue",label = "Spondilolisthesis")
plt.scatter(normal.lumbar_lordosis_angle, normal.degree_spondylolisthesis, color = "green",label = "Normal")
plt.legend()
plt.xlabel("Lumbar Lordosis")
plt.ylabel("Degree Spondylolisthesis")
plt.show()



from sklearn.cross_validation import train_test_split
x_train,x_test,y_train,y_test = train_test_split(x,y,test_size=0.2, random_state=7)

from sklearn.preprocessing import StandardScaler
sc = StandardScaler()

x_train = sc.fit_transform(x_train)
x_test = sc.fit_transform(x_test)
#Creating the model
from sklearn.ensemble import RandomForestClassifier
model = RandomForestClassifier(n_estimators = 150, max_depth=6, random_state=5630)
#Fit Model on training data
model.fit(x_train, y_train)


y_pred = model.predict(x_test)
print(y_pred)

from sklearn.metrics import confusion_matrix
cm = confusion_matrix(y_test,y_pred)
print(cm)

print(model.score(x_test, y_test))

