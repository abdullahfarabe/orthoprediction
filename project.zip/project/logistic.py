
import numpy as np 
import pandas as pd 

dataset = pd.read_csv('column_3C_weka.csv')
data = pd.read_csv("column_3C_weka.csv")
print(data.head())


x = dataset.iloc[:,1:6].values
y= dataset.iloc[:,6].values
data.rename(columns={
    'class': 'symptom_class'
}, inplace=True)

hernia = data[data.symptom_class == "Hernia"]
spondilolisthesis = data[data.symptom_class == "Spondylolisthesis"]
normal = data[data.symptom_class == "Normal"]
plt.scatter(hernia.lumbar_lordosis_angle, hernia.degree_spondylolisthesis, color = "red",label = "Hernia")
plt.scatter(spondilolisthesis.lumbar_lordosis_angle, spondilolisthesis.degree_spondylolisthesis, color = "blue",label = "Spondilolisthesis")
plt.scatter(normal.lumbar_lordosis_angle, normal.degree_spondylolisthesis, color = "green",label = "Normal")
plt.legend()
plt.xlabel("Lumbar Lordosis")
plt.ylabel("Degree Spondylolisthesis")
plt.show()


# Split the data into Training and Testing set
from sklearn.cross_validation import train_test_split
x_train,x_test,y_train,y_test = train_test_split(x,y,test_size=0.2,random_state=0)

# Feature scaling
from sklearn.preprocessing import StandardScaler
sc = StandardScaler()

x_train = sc.fit_transform(x_train)
x_test = sc.fit_transform(x_test)

#Fitting logistic regression to the training set
from sklearn.linear_model import LogisticRegression
classifier = LogisticRegression(random_state = 0)
classifier.fit(x_train,y_train)

# Predicting the Test set results
y_pred = classifier.predict(x_test)

print(y_pred)

# Making the confusion matrix 
from sklearn.metrics import confusion_matrix
cm = confusion_matrix(y_test,y_pred)

print(cm)

from sklearn.metrics import accuracy_score
print(accuracy_score(y_test, y_pred))
