
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt 

data = pd.read_csv("column_3C_weka.csv")
print(data.head())
x = data.iloc[:,1:6].values
y= data.iloc[:,6].values

data.rename(columns={
    'class': 'symptom_class'
}, inplace=True)

hernia = data[data.symptom_class == "Hernia"]
spondilolisthesis = data[data.symptom_class == "Spondylolisthesis"]
normal = data[data.symptom_class == "Normal"]
plt.scatter(hernia.lumbar_lordosis_angle, hernia.degree_spondylolisthesis, color = "red",label = "Hernia")
plt.scatter(spondilolisthesis.lumbar_lordosis_angle, spondilolisthesis.degree_spondylolisthesis, color = "blue",label = "Spondilolisthesis")
plt.scatter(normal.lumbar_lordosis_angle, normal.degree_spondylolisthesis, color = "green",label = "Normal")
plt.legend()
plt.xlabel("Lumbar Lordosis")
plt.ylabel("Degree Spondylolisthesis")
plt.show()

from sklearn.model_selection import train_test_split
x_train, x_test, y_train, y_test = train_test_split(x, y, test_size=0.2,random_state =42)

from sklearn.preprocessing import StandardScaler
sc = StandardScaler()

x_train = sc.fit_transform(x_train)
x_test = sc.fit_transform(x_test)

from sklearn.neighbors import KNeighborsClassifier
knn = KNeighborsClassifier(n_neighbors = 3) #set K neighbor as 3
knn.fit(x_train,y_train)

y_pred = knn.predict(x_test)
print(y_pred)

from sklearn.metrics import confusion_matrix
cm = confusion_matrix(y_test,y_pred)
print(cm)
print(knn.score(x_test,y_test))

data.head();